
#include <stdarg.h>
#include "vpi_user.h"


void vvp_vpi_init()
{
}

