#include <stdlib.h>

void finish(void)
{
   exit(0);
}
