/******************************************************************************

	    COPYRIGHT (c) 2005, 2008 by Reprise Software, Inc.
	This software has been provided pursuant to a License Agreement
	containing restrictions on its use.  This software contains
	valuable trade secrets and proprietary information of 
	Reprise Software Inc and is protected by law.  It may not be 
	copied or distributed in any form or medium, disclosed to third 
	parties, reverse engineered or used in any manner not provided 
	for in said License Agreement except with the prior written 
	authorization from Reprise Software Inc.

 *****************************************************************************/
/*	
 *	Description: 	rlm_isv_config.c - configuration data for ISV 
 *
 *	M. Christiano
 *	11/25/05
 *
 */

#include "license.h"
#include "license_to_run.h"

void
rlm_isv_config(RLM_HANDLE handle)
{
/*
 *	NOTE: Your ISV name is, in general, case-insensitive.
 *	      The ONLY exception to this is when it is used as
 *	      a lockfile name using a FLEXlm-compatible lockfile.
 *	      In this case (and this case only), the case of the
 *	      name you enter here is important.  Note that even in
 *	      this case, ONLY THE LOCKFILE NAME uses the exact case
 *	      you enter - every other place in RLM uses a lowercase
 *	      version of this name.
 */

	/* Set ISV name */
	/*
	 * NOTE: IF you are evaluating RLM, DO NOT change the ISV
	 *	 name, or your license keys will no longer work.
	 *	 For eval kits, the name on the next line MUST
	 *	 be "demo".
	 */
 	rlm_isv_cfg_set_name(handle, "demo");

	/* Set RLM license - do not modify this line */
	rlm_isv_cfg_set_license(handle, RLM_LICENSE_TO_RUN);

	/* Set to non-zero to use a FLEXlm-style lockfile */
	rlm_isv_cfg_set_use_flexlm_lockfile(handle, 0);

/*
 *	If you want to add ISV-defined hostids to the ISV server,
 *	use code similar to the following for each new hostid type
 *	you would like to add.
 */
#if 0
	stat = rlm_add_isv_hostid
		(
			handle, 	/* RLM_HANDLE passed in */
			"keyword here",	/* Hostid keyword you chose */
			YOU_DEFINE_HOSTID_TYPE, /* Your hostid type (int) 
						   > RLM_ISV_HID_TYPE_MIN */
			transient,	/* (int) == 0 if hostid does not change.
					   Non-zero if it does change, e.g., if
					   your hostid is a dongle, it can
					   change if someone unplugs it, so
					   you should set transient non-zero */
			get_type_hostid	/* Your function to determine the
					   hostid value */
		);
	if (stat)
	{
		printf("ERROR: add hostid type returns %d\n", stat);
	}
#endif

}
