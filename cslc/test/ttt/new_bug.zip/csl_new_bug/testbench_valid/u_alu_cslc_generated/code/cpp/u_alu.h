#ifndef INC_GUARD_u_alu_h
#define INC_GUARD_u_alu_h

const int P_CLK_UPPER = 0;
const int P_CLK_LOWER = 0;
const int P_CLK_WIDTH = 0-0+1;

const int 0P_P_CIN_UPPER = 0;
const int P_P_CIN_LOWER = 0;
const int P_P_CIN_WIDTH = 0-0+1;

const int 0P_P_OP1_UPPER = 7;
const int P_P_OP1_LOWER = 0;
const int P_P_OP1_WIDTH = 7-0+1;

const int 0P_P_OP2_UPPER = 7;
const int P_P_OP2_LOWER = 0;
const int P_P_OP2_WIDTH = 7-0+1;

const int 0P_P_RES_UPPER = 7;
const int P_P_RES_LOWER = 0;
const int P_P_RES_WIDTH = 7-0+1;

const int 0P_P_COUT_UPPER = 0;
const int P_P_COUT_LOWER = 0;
const int P_P_COUT_WIDTH = 0-0+1;

const int 0P_P_SEL_UPPER = 1;
const int P_P_SEL_LOWER = 0;
const int P_P_SEL_WIDTH = 1-0+1;

const int 0S_CLK1_UPPER = 0;
const int S_CLK1_LOWER = 0;
const int S_CLK1_WIDTH = 0-0+1;

const int 0S_OP_UPPER = 19-1;
const int S_OP_LOWER = 0;
const int S_OP_WIDTH = 19;

const int S_OUT_UPPER = 9-1;
const int S_OUT_LOWER = 0;
const int S_OUT_WIDTH = 9;

clk1clkopp_cinp_op1p_op2p_seloutp_resp_cout
#endif
