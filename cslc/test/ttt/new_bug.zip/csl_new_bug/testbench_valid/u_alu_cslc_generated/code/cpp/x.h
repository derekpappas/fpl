unit decl
ID----------> u_alu
interface
ID----------> *u_alu_default_ifc
interface child 
port
ID----------> clk
portDecl child 
bitrange
ID----------> *CSLBitRange_0
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> p_cin
portDecl child 
bitrange
ID----------> *CSLBitRange_1
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> p_op1
portDecl child 
bitrange
ID----------> *CSLBitRange_2
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> p_op2
portDecl child 
bitrange
ID----------> *CSLBitRange_3
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> p_res
portDecl child 
bitrange
ID----------> *CSLBitRange_4
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> p_cout
portDecl child 
bitrange
ID----------> *CSLBitRange_5
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> p_sel
portDecl child 
bitrange
ID----------> *CSLBitRange_6
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
interface END
signal
ID----------> clk1
bitrange
ID----------> *CSLBitRange_7
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> op
bitrange
ID----------> *CSLBitRange_8
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
signal END
signal
ID----------> out
bitrange
ID----------> *CSLBitRange_9
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
signal END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
exprConcat
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
exprConcat
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
unit END
unit decl
ID----------> v_stim
interface
ID----------> *v_stim_default_ifc
interface child 
interface END
unit END
unit decl
ID----------> v_expect
interface
ID----------> *v_expect_default_ifc
interface child 
interface END
unit END
unit decl
ID----------> tb_alu
interface
ID----------> *tb_alu_default_ifc
interface child 
interface END
signal
ID----------> clk
bitrange
ID----------> *CSLBitRange_10
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
expr link
expr link  child
expr link END
ID----------> alu
unit END
