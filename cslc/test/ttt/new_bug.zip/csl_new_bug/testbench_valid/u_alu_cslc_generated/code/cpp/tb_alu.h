#ifndef INC_GUARD_tb_alu_h
#define INC_GUARD_tb_alu_h

const int S_CLK_UPPER = 0;
const int S_CLK_LOWER = 0;
const int S_CLK_WIDTH = 0-0+1;

u_alu
#endif
