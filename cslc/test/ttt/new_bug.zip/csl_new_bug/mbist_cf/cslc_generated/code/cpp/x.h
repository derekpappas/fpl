enum
ID----------> e_opcode
ID----------> e_add
ID----------> e_sub
ID----------> e_or
ID----------> e_not
ID----------> e_cmp
ID----------> e_br
ID----------> e_sh
ID----------> e_mov
ID----------> e_movmr
ID----------> e_movrm
ID----------> e_movr
ID----------> e_movc
ID----------> e_movs
ID----------> e_incr
ID----------> e_decr
enum END
isa field
ID----------> f_opcode
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> r_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> c_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> b_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> m_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> o_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> rom_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> sr_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa field
ID----------> cond_field
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field END
isa element
ID----------> isa_root
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa element END
isa element
ID----------> base_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa element END
isa element
ID----------> f1_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa element END
isa element
ID----------> op_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> op1_field
====number
====number
====number
isa field END
isa field
ID----------> op2_field
====number
====number
====number
isa field END
isa element END
isa element
ID----------> br_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> cond_field0
====number
====number
====number
isa field END
isa field
ID----------> br_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> r_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> m_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> m_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> rom_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> rom_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> const_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> const_nmb
====number
====number
====number
isa field END
isa element END
isa element
ID----------> sr_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> sr_addr
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> sh_format
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> sha
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_add
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> op1_field
====number
====number
====number
isa field END
isa field
ID----------> op2_field
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_sub
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> op1_field
====number
====number
====number
isa field END
isa field
ID----------> op2_field
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_or
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> op1_field
====number
====number
====number
isa field END
isa field
ID----------> op2_field
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_not
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> op1_field
====number
====number
====number
isa field END
isa field
ID----------> op2_field
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_cmp
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_br
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> cond_field0
====number
====number
====number
isa field END
isa field
ID----------> br_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_sh
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> sha
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_rt
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_fromm
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> m_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_tomem
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> m_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_rom
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> rom_addr
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_ctor
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> dst_r_field
====number
====number
====number
isa field END
isa field
ID----------> const_nmb
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_tosr
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa field
ID----------> sr_addr
====number
====number
====number
isa field END
isa field
ID----------> r_src
====number
====number
====number
isa field END
isa element END
isa element
ID----------> i_incr
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa element END
isa element
ID----------> i_decr
====number
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
====number
isa field
ID----------> f_opcode
====number
====number
====number
expr link
expr link  child
expr link END
isa field END
isa element END
