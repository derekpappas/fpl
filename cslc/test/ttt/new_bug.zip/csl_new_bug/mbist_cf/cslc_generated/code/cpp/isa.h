#ifndef INC_GUARD_ISA_h
#define INC_GUARD_ISA_h

const int IF_F_OPCODE_UPPER = 4;
const int IF_F_OPCODE_LOWER = 0;
const int IF_F_OPCODE_WIDTH = 4e_opcode;

const int IF_R_FIELD_UPPER = 4;
const int IF_R_FIELD_LOWER = 0;
const int IF_R_FIELD_WIDTH = 4;

const int IF_C_FIELD_UPPER = 8;
const int IF_C_FIELD_LOWER = 0;
const int IF_C_FIELD_WIDTH = 8;

const int IF_B_FIELD_UPPER = 11;
const int IF_B_FIELD_LOWER = 0;
const int IF_B_FIELD_WIDTH = 11;

const int IF_M_FIELD_UPPER = 8;
const int IF_M_FIELD_LOWER = 0;
const int IF_M_FIELD_WIDTH = 8;

const int IF_O_FIELD_UPPER = 4;
const int IF_O_FIELD_LOWER = 0;
const int IF_O_FIELD_WIDTH = 4;

const int IF_ROM_FIELD_UPPER = 8;
const int IF_ROM_FIELD_LOWER = 0;
const int IF_ROM_FIELD_WIDTH = 8;

const int IF_SR_FIELD_UPPER = 8;
const int IF_SR_FIELD_LOWER = 0;
const int IF_SR_FIELD_WIDTH = 8;

const int IF_COND_FIELD_UPPER = 1;
const int IF_COND_FIELD_LOWER = 0;
const int IF_COND_FIELD_WIDTH = 1;

const int IE_ISA_ROOT_UPPER = 16;
const int IE_ISA_ROOT_LOWER = 0;
const int IE_ISA_ROOT_WIDTH = 16;

const int IE_BASE_FORMAT_UPPER = 16;
const int IE_BASE_FORMAT_LOWER = 0;
const int IE_BASE_FORMAT_WIDTH = 16;
const int IE_BASE_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_BASE_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_BASE_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;

const int IE_F1_FORMAT_UPPER = 16;
const int IE_F1_FORMAT_LOWER = 0;
const int IE_F1_FORMAT_WIDTH = 16;
const int IE_F1_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_F1_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_F1_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_F1_FORMAT_IF_DST_R_FIELD_UPPER = 3;
const int IE_F1_FORMAT_IF_DST_R_FIELD_LOWER = 0;
const int IE_F1_FORMAT_IF_DST_R_FIELD_WIDTH = 4;

const int IE_OP_FORMAT_UPPER = 16;
const int IE_OP_FORMAT_LOWER = 0;
const int IE_OP_FORMAT_WIDTH = 16;
const int IE_OP_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_OP_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_OP_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_OP_FORMAT_IF_DST_R_FIELD_UPPER = 3;
const int IE_OP_FORMAT_IF_DST_R_FIELD_LOWER = 0;
const int IE_OP_FORMAT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_OP_FORMAT_IF_OP1_FIELD_UPPER = 3;
const int IE_OP_FORMAT_IF_OP1_FIELD_LOWER = 0;
const int IE_OP_FORMAT_IF_OP1_FIELD_WIDTH = 4;
const int IE_OP_FORMAT_IF_OP2_FIELD_UPPER = 3;
const int IE_OP_FORMAT_IF_OP2_FIELD_LOWER = 0;
const int IE_OP_FORMAT_IF_OP2_FIELD_WIDTH = 4;

const int IE_BR_FORMAT_UPPER = 16;
const int IE_BR_FORMAT_LOWER = 0;
const int IE_BR_FORMAT_WIDTH = 16;
const int IE_BR_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_BR_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_BR_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_BR_FORMAT_IF_COND_FIELD0_UPPER = 0;
const int IE_BR_FORMAT_IF_COND_FIELD0_LOWER = 0;
const int IE_BR_FORMAT_IF_COND_FIELD0_WIDTH = 1;
const int IE_BR_FORMAT_IF_BR_ADDR_UPPER = 10;
const int IE_BR_FORMAT_IF_BR_ADDR_LOWER = 0;
const int IE_BR_FORMAT_IF_BR_ADDR_WIDTH = 11;

const int IE_R_FORMAT_UPPER = 16;
const int IE_R_FORMAT_LOWER = 0;
const int IE_R_FORMAT_WIDTH = 16;
const int IE_R_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_R_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_R_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_R_FORMAT_IF_DST_R_FIELD_UPPER = 3;
const int IE_R_FORMAT_IF_DST_R_FIELD_LOWER = 0;
const int IE_R_FORMAT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_R_FORMAT_IF_R_SRC_UPPER = 3;
const int IE_R_FORMAT_IF_R_SRC_LOWER = 0;
const int IE_R_FORMAT_IF_R_SRC_WIDTH = 4;

const int IE_M_FORMAT_UPPER = 16;
const int IE_M_FORMAT_LOWER = 0;
const int IE_M_FORMAT_WIDTH = 16;
const int IE_M_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_M_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_M_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_M_FORMAT_IF_DST_R_FIELD_UPPER = 3;
const int IE_M_FORMAT_IF_DST_R_FIELD_LOWER = 0;
const int IE_M_FORMAT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_M_FORMAT_IF_M_ADDR_UPPER = 7;
const int IE_M_FORMAT_IF_M_ADDR_LOWER = 0;
const int IE_M_FORMAT_IF_M_ADDR_WIDTH = 8;

const int IE_ROM_FORMAT_UPPER = 16;
const int IE_ROM_FORMAT_LOWER = 0;
const int IE_ROM_FORMAT_WIDTH = 16;
const int IE_ROM_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_ROM_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_ROM_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_ROM_FORMAT_IF_DST_R_FIELD_UPPER = 3;
const int IE_ROM_FORMAT_IF_DST_R_FIELD_LOWER = 0;
const int IE_ROM_FORMAT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_ROM_FORMAT_IF_ROM_ADDR_UPPER = 7;
const int IE_ROM_FORMAT_IF_ROM_ADDR_LOWER = 0;
const int IE_ROM_FORMAT_IF_ROM_ADDR_WIDTH = 8;

const int IE_CONST_FORMAT_UPPER = 16;
const int IE_CONST_FORMAT_LOWER = 0;
const int IE_CONST_FORMAT_WIDTH = 16;
const int IE_CONST_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_CONST_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_CONST_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_CONST_FORMAT_IF_DST_R_FIELD_UPPER = 3;
const int IE_CONST_FORMAT_IF_DST_R_FIELD_LOWER = 0;
const int IE_CONST_FORMAT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_CONST_FORMAT_IF_CONST_NMB_UPPER = 7;
const int IE_CONST_FORMAT_IF_CONST_NMB_LOWER = 0;
const int IE_CONST_FORMAT_IF_CONST_NMB_WIDTH = 8;

const int IE_SR_FORMAT_UPPER = 16;
const int IE_SR_FORMAT_LOWER = 0;
const int IE_SR_FORMAT_WIDTH = 16;
const int IE_SR_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_SR_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_SR_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_SR_FORMAT_IF_SR_ADDR_UPPER = 7;
const int IE_SR_FORMAT_IF_SR_ADDR_LOWER = 0;
const int IE_SR_FORMAT_IF_SR_ADDR_WIDTH = 8;
const int IE_SR_FORMAT_IF_R_SRC_UPPER = 3;
const int IE_SR_FORMAT_IF_R_SRC_LOWER = 0;
const int IE_SR_FORMAT_IF_R_SRC_WIDTH = 4;

const int IE_SH_FORMAT_UPPER = 16;
const int IE_SH_FORMAT_LOWER = 0;
const int IE_SH_FORMAT_WIDTH = 16;
const int IE_SH_FORMAT_IF_F_OPCODE_UPPER = 3;
const int IE_SH_FORMAT_IF_F_OPCODE_LOWER = 0;
const int IE_SH_FORMAT_IF_F_OPCODE_WIDTH = 4e_opcode;
const int IE_SH_FORMAT_IF_SHA_UPPER = 3;
const int IE_SH_FORMAT_IF_SHA_LOWER = 0;
const int IE_SH_FORMAT_IF_SHA_WIDTH = 4;
const int IE_SH_FORMAT_IF_R_SRC_UPPER = 3;
const int IE_SH_FORMAT_IF_R_SRC_LOWER = 0;
const int IE_SH_FORMAT_IF_R_SRC_WIDTH = 4;

const int IE_I_ADD_UPPER = 16;
const int IE_I_ADD_LOWER = 0;
const int IE_I_ADD_WIDTH = 16;
const int IE_I_ADD_IF_F_OPCODE_UPPER = 3;
const int IE_I_ADD_IF_F_OPCODE_LOWER = 0;
const int IE_I_ADD_IF_F_OPCODE_WIDTH = 4e_add;
const int IE_I_ADD_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_ADD_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_ADD_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_ADD_IF_OP1_FIELD_UPPER = 3;
const int IE_I_ADD_IF_OP1_FIELD_LOWER = 0;
const int IE_I_ADD_IF_OP1_FIELD_WIDTH = 4;
const int IE_I_ADD_IF_OP2_FIELD_UPPER = 3;
const int IE_I_ADD_IF_OP2_FIELD_LOWER = 0;
const int IE_I_ADD_IF_OP2_FIELD_WIDTH = 4;

const int IE_I_SUB_UPPER = 16;
const int IE_I_SUB_LOWER = 0;
const int IE_I_SUB_WIDTH = 16;
const int IE_I_SUB_IF_F_OPCODE_UPPER = 3;
const int IE_I_SUB_IF_F_OPCODE_LOWER = 0;
const int IE_I_SUB_IF_F_OPCODE_WIDTH = 4e_sub;
const int IE_I_SUB_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_SUB_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_SUB_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_SUB_IF_OP1_FIELD_UPPER = 3;
const int IE_I_SUB_IF_OP1_FIELD_LOWER = 0;
const int IE_I_SUB_IF_OP1_FIELD_WIDTH = 4;
const int IE_I_SUB_IF_OP2_FIELD_UPPER = 3;
const int IE_I_SUB_IF_OP2_FIELD_LOWER = 0;
const int IE_I_SUB_IF_OP2_FIELD_WIDTH = 4;

const int IE_I_OR_UPPER = 16;
const int IE_I_OR_LOWER = 0;
const int IE_I_OR_WIDTH = 16;
const int IE_I_OR_IF_F_OPCODE_UPPER = 3;
const int IE_I_OR_IF_F_OPCODE_LOWER = 0;
const int IE_I_OR_IF_F_OPCODE_WIDTH = 4e_or;
const int IE_I_OR_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_OR_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_OR_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_OR_IF_OP1_FIELD_UPPER = 3;
const int IE_I_OR_IF_OP1_FIELD_LOWER = 0;
const int IE_I_OR_IF_OP1_FIELD_WIDTH = 4;
const int IE_I_OR_IF_OP2_FIELD_UPPER = 3;
const int IE_I_OR_IF_OP2_FIELD_LOWER = 0;
const int IE_I_OR_IF_OP2_FIELD_WIDTH = 4;

const int IE_I_NOT_UPPER = 16;
const int IE_I_NOT_LOWER = 0;
const int IE_I_NOT_WIDTH = 16;
const int IE_I_NOT_IF_F_OPCODE_UPPER = 3;
const int IE_I_NOT_IF_F_OPCODE_LOWER = 0;
const int IE_I_NOT_IF_F_OPCODE_WIDTH = 4e_not;
const int IE_I_NOT_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_NOT_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_NOT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_NOT_IF_OP1_FIELD_UPPER = 3;
const int IE_I_NOT_IF_OP1_FIELD_LOWER = 0;
const int IE_I_NOT_IF_OP1_FIELD_WIDTH = 4;
const int IE_I_NOT_IF_OP2_FIELD_UPPER = 3;
const int IE_I_NOT_IF_OP2_FIELD_LOWER = 0;
const int IE_I_NOT_IF_OP2_FIELD_WIDTH = 4;

const int IE_I_CMP_UPPER = 16;
const int IE_I_CMP_LOWER = 0;
const int IE_I_CMP_WIDTH = 16;
const int IE_I_CMP_IF_F_OPCODE_UPPER = 3;
const int IE_I_CMP_IF_F_OPCODE_LOWER = 0;
const int IE_I_CMP_IF_F_OPCODE_WIDTH = 4e_cmp;
const int IE_I_CMP_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_CMP_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_CMP_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_CMP_IF_R_SRC_UPPER = 3;
const int IE_I_CMP_IF_R_SRC_LOWER = 0;
const int IE_I_CMP_IF_R_SRC_WIDTH = 4;

const int IE_I_BR_UPPER = 16;
const int IE_I_BR_LOWER = 0;
const int IE_I_BR_WIDTH = 16;
const int IE_I_BR_IF_F_OPCODE_UPPER = 3;
const int IE_I_BR_IF_F_OPCODE_LOWER = 0;
const int IE_I_BR_IF_F_OPCODE_WIDTH = 4e_br;
const int IE_I_BR_IF_COND_FIELD0_UPPER = 0;
const int IE_I_BR_IF_COND_FIELD0_LOWER = 0;
const int IE_I_BR_IF_COND_FIELD0_WIDTH = 1;
const int IE_I_BR_IF_BR_ADDR_UPPER = 10;
const int IE_I_BR_IF_BR_ADDR_LOWER = 0;
const int IE_I_BR_IF_BR_ADDR_WIDTH = 11;

const int IE_I_SH_UPPER = 16;
const int IE_I_SH_LOWER = 0;
const int IE_I_SH_WIDTH = 16;
const int IE_I_SH_IF_F_OPCODE_UPPER = 3;
const int IE_I_SH_IF_F_OPCODE_LOWER = 0;
const int IE_I_SH_IF_F_OPCODE_WIDTH = 4e_sh;
const int IE_I_SH_IF_SHA_UPPER = 3;
const int IE_I_SH_IF_SHA_LOWER = 0;
const int IE_I_SH_IF_SHA_WIDTH = 4;
const int IE_I_SH_IF_R_SRC_UPPER = 3;
const int IE_I_SH_IF_R_SRC_LOWER = 0;
const int IE_I_SH_IF_R_SRC_WIDTH = 4;

const int IE_I_RT_UPPER = 16;
const int IE_I_RT_LOWER = 0;
const int IE_I_RT_WIDTH = 16;
const int IE_I_RT_IF_F_OPCODE_UPPER = 3;
const int IE_I_RT_IF_F_OPCODE_LOWER = 0;
const int IE_I_RT_IF_F_OPCODE_WIDTH = 4e_mov;
const int IE_I_RT_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_RT_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_RT_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_RT_IF_R_SRC_UPPER = 3;
const int IE_I_RT_IF_R_SRC_LOWER = 0;
const int IE_I_RT_IF_R_SRC_WIDTH = 4;

const int IE_I_FROMM_UPPER = 16;
const int IE_I_FROMM_LOWER = 0;
const int IE_I_FROMM_WIDTH = 16;
const int IE_I_FROMM_IF_F_OPCODE_UPPER = 3;
const int IE_I_FROMM_IF_F_OPCODE_LOWER = 0;
const int IE_I_FROMM_IF_F_OPCODE_WIDTH = 4e_movmr;
const int IE_I_FROMM_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_FROMM_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_FROMM_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_FROMM_IF_M_ADDR_UPPER = 7;
const int IE_I_FROMM_IF_M_ADDR_LOWER = 0;
const int IE_I_FROMM_IF_M_ADDR_WIDTH = 8;

const int IE_I_TOMEM_UPPER = 16;
const int IE_I_TOMEM_LOWER = 0;
const int IE_I_TOMEM_WIDTH = 16;
const int IE_I_TOMEM_IF_F_OPCODE_UPPER = 3;
const int IE_I_TOMEM_IF_F_OPCODE_LOWER = 0;
const int IE_I_TOMEM_IF_F_OPCODE_WIDTH = 4e_movrm;
const int IE_I_TOMEM_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_TOMEM_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_TOMEM_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_TOMEM_IF_M_ADDR_UPPER = 7;
const int IE_I_TOMEM_IF_M_ADDR_LOWER = 0;
const int IE_I_TOMEM_IF_M_ADDR_WIDTH = 8;

const int IE_I_ROM_UPPER = 16;
const int IE_I_ROM_LOWER = 0;
const int IE_I_ROM_WIDTH = 16;
const int IE_I_ROM_IF_F_OPCODE_UPPER = 3;
const int IE_I_ROM_IF_F_OPCODE_LOWER = 0;
const int IE_I_ROM_IF_F_OPCODE_WIDTH = 4e_movr;
const int IE_I_ROM_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_ROM_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_ROM_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_ROM_IF_ROM_ADDR_UPPER = 7;
const int IE_I_ROM_IF_ROM_ADDR_LOWER = 0;
const int IE_I_ROM_IF_ROM_ADDR_WIDTH = 8;

const int IE_I_CTOR_UPPER = 16;
const int IE_I_CTOR_LOWER = 0;
const int IE_I_CTOR_WIDTH = 16;
const int IE_I_CTOR_IF_F_OPCODE_UPPER = 3;
const int IE_I_CTOR_IF_F_OPCODE_LOWER = 0;
const int IE_I_CTOR_IF_F_OPCODE_WIDTH = 4e_movc;
const int IE_I_CTOR_IF_DST_R_FIELD_UPPER = 3;
const int IE_I_CTOR_IF_DST_R_FIELD_LOWER = 0;
const int IE_I_CTOR_IF_DST_R_FIELD_WIDTH = 4;
const int IE_I_CTOR_IF_CONST_NMB_UPPER = 7;
const int IE_I_CTOR_IF_CONST_NMB_LOWER = 0;
const int IE_I_CTOR_IF_CONST_NMB_WIDTH = 8;

const int IE_I_TOSR_UPPER = 16;
const int IE_I_TOSR_LOWER = 0;
const int IE_I_TOSR_WIDTH = 16;
const int IE_I_TOSR_IF_F_OPCODE_UPPER = 3;
const int IE_I_TOSR_IF_F_OPCODE_LOWER = 0;
const int IE_I_TOSR_IF_F_OPCODE_WIDTH = 4e_movs;
const int IE_I_TOSR_IF_SR_ADDR_UPPER = 7;
const int IE_I_TOSR_IF_SR_ADDR_LOWER = 0;
const int IE_I_TOSR_IF_SR_ADDR_WIDTH = 8;
const int IE_I_TOSR_IF_R_SRC_UPPER = 3;
const int IE_I_TOSR_IF_R_SRC_LOWER = 0;
const int IE_I_TOSR_IF_R_SRC_WIDTH = 4;

const int IE_I_INCR_UPPER = 16;
const int IE_I_INCR_LOWER = 0;
const int IE_I_INCR_WIDTH = 16;
const int IE_I_INCR_IF_F_OPCODE_UPPER = 3;
const int IE_I_INCR_IF_F_OPCODE_LOWER = 0;
const int IE_I_INCR_IF_F_OPCODE_WIDTH = 4e_incr;

const int IE_I_DECR_UPPER = 16;
const int IE_I_DECR_LOWER = 0;
const int IE_I_DECR_WIDTH = 16;
const int IE_I_DECR_IF_F_OPCODE_UPPER = 3;
const int IE_I_DECR_IF_F_OPCODE_LOWER = 0;
const int IE_I_DECR_IF_F_OPCODE_WIDTH = 4e_decr;


#endif
