#ifndef INC_GUARD_ENUM_h
#define INC_GUARD_ENUM_h

enum E_E_OPCODE{
	E_ADD = 0,
	E_SUB = 1,
	E_OR = 2,
	E_NOT = 3,
	E_CMP = 4,
	E_BR = 5,
	E_SH = 6,
	E_MOV = 15,
	E_MOVMR = 8,
	E_MOVRM = 9,
	E_MOVR = 12,
	E_MOVC = 13,
	E_MOVS = 14,
	E_INCR = 10,
	E_DECR = 11
};

#endif
