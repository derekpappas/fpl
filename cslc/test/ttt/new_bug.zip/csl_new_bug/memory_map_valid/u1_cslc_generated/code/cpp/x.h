unit decl
ID----------> u1
interface
ID----------> *u1_default_ifc
interface child 
interface END
unit END
ID----------> mpg1
ID----------> *CSLAddressRange_0
====number
====number
====number
ID----------> *CSLAddressRange_1
====number
====number
====number
ID----------> mpg2
ID----------> *CSLAddressRange_2
====number
====number
====number
ID----------> *CSLAddressRange_3
====number
====number
====number
ID----------> mp
enum
ID----------> default_group
ID----------> user
ID----------> sw
ID----------> hw
ID----------> test
ID----------> driver
enum END
