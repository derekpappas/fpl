unit decl
ID----------> top
interface
ID----------> *top_default_ifc
interface child 
interface END
unit END
ID----------> mem_x
ID----------> *CSLAddressRange_0
====number
====number
====number
ID----------> *CSLAddressRange_1
====number
====number
====number
