unit decl
ID----------> u
interface
ID----------> *u_default_ifc
interface child 
interface END
unit END
ID----------> mmp_page
ID----------> *CSLAddressRange_0
====number
====number
====number
ID----------> *CSLAddressRange_1
====number
====number
====number
ID----------> mm
enum
ID----------> default_group
ID----------> user
ID----------> sw
ID----------> hw
ID----------> test
ID----------> driver
enum END
