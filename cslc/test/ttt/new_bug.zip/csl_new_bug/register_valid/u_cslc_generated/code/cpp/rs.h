#ifndef INC_GUARD_rs_h
#define INC_GUARD_rs_h

const int P_RESET__UPPER = 0;
const int P_RESET__LOWER = 0;
const int P_RESET__WIDTH = 0-0+1;

const int 0P_ENABLE_UPPER = 0;
const int P_ENABLE_LOWER = 0;
const int P_ENABLE_WIDTH = 0-0+1;

const int 0P_CLOCK_UPPER = 0;
const int P_CLOCK_LOWER = 0;
const int P_CLOCK_WIDTH = 0-0+1;

const int 0P_REG_OUT_UPPER = 32-1;
const int P_REG_OUT_LOWER = 0;
const int P_REG_OUT_WIDTH = 32;


#endif
