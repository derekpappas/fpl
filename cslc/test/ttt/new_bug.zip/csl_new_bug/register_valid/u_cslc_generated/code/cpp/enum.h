#ifndef INC_GUARD_ENUM_h
#define INC_GUARD_ENUM_h

enum E_DEFAULT_GROUP{
	USER = 0,
	SW = 1,
	HW = 2,
	TEST = 3,
	DRIVER = 4
};

#endif
