#ifndef INC_GUARD_u1_h
#define INC_GUARD_u1_h

const int S_RST_UPPER = 0;
const int S_RST_LOWER = 0;
const int S_RST_WIDTH = 0-0+1;

const int 0S_EN_UPPER = 0;
const int S_EN_LOWER = 0;
const int S_EN_WIDTH = 0-0+1;

const int 0S_DATA_UPPER = 67-1;
const int S_DATA_LOWER = 0;
const int S_DATA_WIDTH = 67;

const int S_CLK_UPPER = 0;
const int S_CLK_LOWER = 0;
const int S_CLK_WIDTH = 0-0+1;

r1
#endif
