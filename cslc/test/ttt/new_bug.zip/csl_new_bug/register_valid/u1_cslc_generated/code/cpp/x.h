unit decl
ID----------> r1
interface
ID----------> *r1_default_ifc
interface child 
port
ID----------> reset_
portDecl child 
bitrange
ID----------> *CSLBitRange_0
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> enable
portDecl child 
bitrange
ID----------> *CSLBitRange_1
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> clock
portDecl child 
bitrange
ID----------> *CSLBitRange_2
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> reg_out
portDecl child 
bitrange
ID----------> *CSLBitRange_3
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> reg_in
portDecl child 
bitrange
ID----------> *CSLBitRange_4
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
interface END
unit END
unit decl
ID----------> u1
interface
ID----------> *u1_default_ifc
interface child 
interface END
signal
ID----------> rst
bitrange
ID----------> *CSLBitRange_5
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> en
bitrange
ID----------> *CSLBitRange_6
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> data
bitrange
ID----------> *CSLBitRange_7
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
signal END
signal
ID----------> clk
bitrange
ID----------> *CSLBitRange_8
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
expr link
expr link  child
expr link END
ID----------> r1
unit END
