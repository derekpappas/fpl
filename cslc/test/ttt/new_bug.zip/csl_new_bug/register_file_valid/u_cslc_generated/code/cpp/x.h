unit decl
ID----------> rf
====number
====number
interface
ID----------> *rf_default_ifc
interface child 
port
ID----------> reset
portDecl child 
bitrange
ID----------> *CSLBitRange_0
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> clear
portDecl child 
bitrange
ID----------> *CSLBitRange_1
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> clock
portDecl child 
bitrange
ID----------> *CSLBitRange_2
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> wr_addr
portDecl child 
bitrange
ID----------> *CSLBitRange_3
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
exprOp
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
exprOp
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> rd_addr0
portDecl child 
bitrange
ID----------> *CSLBitRange_4
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
exprOp
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
exprOp
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> rd_addr1
portDecl child 
bitrange
ID----------> *CSLBitRange_5
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
exprOp
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
exprOp
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> data_in
portDecl child 
bitrange
ID----------> *CSLBitRange_6
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> data_out0
portDecl child 
bitrange
ID----------> *CSLBitRange_7
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> data_out1
portDecl child 
bitrange
ID----------> *CSLBitRange_8
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> wr_en
portDecl child 
bitrange
ID----------> *CSLBitRange_9
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> rd_en0
portDecl child 
bitrange
ID----------> *CSLBitRange_10
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> rd_en1
portDecl child 
bitrange
ID----------> *CSLBitRange_11
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> valid
portDecl child 
bitrange
ID----------> *CSLBitRange_12
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
interface END
unit END
unit decl
ID----------> u
interface
ID----------> *u_default_ifc
interface child 
interface END
signal
ID----------> clk
bitrange
ID----------> *CSLBitRange_13
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> addr
bitrange
ID----------> *CSLBitRange_14
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
signal END
signal
ID----------> data
bitrange
ID----------> *CSLBitRange_15
simpleBitRange child 1
====number
simpleBitRange child 2
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 3
====number
====number
simpleBitRange child 4
bit range END
signal END
signal
ID----------> en
bitrange
ID----------> *CSLBitRange_16
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> valid
bitrange
ID----------> *CSLBitRange_17
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> rst
bitrange
ID----------> *CSLBitRange_18
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> clr
bitrange
ID----------> *CSLBitRange_19
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
expr link
expr link  child
expr link END
ID----------> rf0
unit END
