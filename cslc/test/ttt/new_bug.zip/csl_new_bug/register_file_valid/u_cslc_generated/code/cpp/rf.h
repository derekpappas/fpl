#ifndef INC_GUARD_rf_h
#define INC_GUARD_rf_h

const int P_RESET_UPPER = 0;
const int P_RESET_LOWER = 0;
const int P_RESET_WIDTH = 0-0+1;

const int 0P_CLEAR_UPPER = 0;
const int P_CLEAR_LOWER = 0;
const int P_CLEAR_WIDTH = 0-0+1;

const int 0P_CLOCK_UPPER = 0;
const int P_CLOCK_LOWER = 0;
const int P_CLOCK_WIDTH = 0-0+1;

const int 0P_WR_ADDR_UPPER = log2 16-1;
const int P_WR_ADDR_LOWER = 0;
const int P_WR_ADDR_WIDTH = log2 16;

const int 0P_RD_ADDR0_UPPER = log2 16-1;
const int P_RD_ADDR0_LOWER = 0;
const int P_RD_ADDR0_WIDTH = log2 16;

const int 0P_RD_ADDR1_UPPER = log2 16-1;
const int P_RD_ADDR1_LOWER = 0;
const int P_RD_ADDR1_WIDTH = log2 16;

const int 0P_DATA_IN_UPPER = 32-1;
const int P_DATA_IN_LOWER = 0;
const int P_DATA_IN_WIDTH = 32;

const int P_DATA_OUT0_UPPER = 32-1;
const int P_DATA_OUT0_LOWER = 0;
const int P_DATA_OUT0_WIDTH = 32;

const int P_DATA_OUT1_UPPER = 32-1;
const int P_DATA_OUT1_LOWER = 0;
const int P_DATA_OUT1_WIDTH = 32;

const int P_WR_EN_UPPER = 0;
const int P_WR_EN_LOWER = 0;
const int P_WR_EN_WIDTH = 0-0+1;

const int 0P_RD_EN0_UPPER = 0;
const int P_RD_EN0_LOWER = 0;
const int P_RD_EN0_WIDTH = 0-0+1;

const int 0P_RD_EN1_UPPER = 0;
const int P_RD_EN1_LOWER = 0;
const int P_RD_EN1_WIDTH = 0-0+1;

const int 0P_VALID_UPPER = 0;
const int P_VALID_LOWER = 0;
const int P_VALID_WIDTH = 0-0+1;


#endif
