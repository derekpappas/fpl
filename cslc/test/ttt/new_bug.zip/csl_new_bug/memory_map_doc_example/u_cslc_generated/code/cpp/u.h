#ifndef INC_GUARD_u_h
#define INC_GUARD_u_h

const int S_S1_UPPER = 0;
const int S_S1_LOWER = 0;
const int S_S1_WIDTH = 0-0+1;

const int 0S_S2_UPPER = 0;
const int S_S2_LOWER = 0;
const int S_S2_WIDTH = 0-0+1;

s1s2
#endif
