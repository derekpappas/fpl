unit decl
ID----------> u
interface
ID----------> *u_default_ifc
interface child 
interface END
signal
ID----------> s1
bitrange
ID----------> *CSLBitRange_0
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
signal
ID----------> s2
bitrange
ID----------> *CSLBitRange_1
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
unit END
ID----------> mpage1
ID----------> *CSLAddressRange_0
