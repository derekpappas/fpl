#ifndef INC_GUARD_top_h
#define INC_GUARD_top_h

const int S_PUSH_UPPER = 0;
const int S_PUSH_LOWER = 0;
const int S_PUSH_WIDTH = 0-0+1;

const int 0S_POP_UPPER = 0;
const int S_POP_LOWER = 0;
const int S_POP_WIDTH = 0-0+1;

const int 0S_FULL_UPPER = 0;
const int S_FULL_LOWER = 0;
const int S_FULL_WIDTH = 0-0+1;

const int 0S_EMPTY_UPPER = 0;
const int S_EMPTY_LOWER = 0;
const int S_EMPTY_WIDTH = 0-0+1;

const int 0S_DATA_UPPER = 8-1;
const int S_DATA_LOWER = 0;
const int S_DATA_WIDTH = 8;

const int S_RST_UPPER = 0;
const int S_RST_LOWER = 0;
const int S_RST_WIDTH = 0-0+1;

const int 0S_VALID_UPPER = 0;
const int S_VALID_LOWER = 0;
const int S_VALID_WIDTH = 0-0+1;

const int 0S_CLK_UPPER = 0;
const int S_CLK_LOWER = 0;
const int S_CLK_WIDTH = 0-0+1;

f1
#endif
