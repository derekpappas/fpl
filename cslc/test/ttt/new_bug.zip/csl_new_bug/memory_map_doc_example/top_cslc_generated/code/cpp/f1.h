#ifndef INC_GUARD_f1_h
#define INC_GUARD_f1_h

const int P_PUSH_UPPER = 1-1;
const int P_PUSH_LOWER = 0;
const int P_PUSH_WIDTH = 1;

const int P_POP_UPPER = 1-1;
const int P_POP_LOWER = 0;
const int P_POP_WIDTH = 1;

const int P_FULL_UPPER = 1-1;
const int P_FULL_LOWER = 0;
const int P_FULL_WIDTH = 1;

const int P_EMPTY_UPPER = 1-1;
const int P_EMPTY_LOWER = 0;
const int P_EMPTY_WIDTH = 1;

const int P_RD_DATA_UPPER = 8-1;
const int P_RD_DATA_LOWER = 0;
const int P_RD_DATA_WIDTH = 8;

const int P_WR_DATA_UPPER = 8-1;
const int P_WR_DATA_LOWER = 0;
const int P_WR_DATA_WIDTH = 8;

const int P_RESET__UPPER = 1-1;
const int P_RESET__LOWER = 0;
const int P_RESET__WIDTH = 1;

const int P_CLOCK_UPPER = 1-1;
const int P_CLOCK_LOWER = 0;
const int P_CLOCK_WIDTH = 1;

const int P_VALID_UPPER = 1-1;
const int P_VALID_LOWER = 0;
const int P_VALID_WIDTH = 1;


#endif
