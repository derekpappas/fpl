unit decl
ID----------> dut_2
interface
ID----------> *dut_2_default_ifc
interface child 
port
ID----------> stim_in
portDecl child 
bitrange
ID----------> *CSLBitRange_0
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> stim_v
portDecl child 
bitrange
ID----------> *CSLBitRange_1
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> exp_d
portDecl child 
bitrange
ID----------> *CSLBitRange_2
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> exp_v
portDecl child 
bitrange
ID----------> *CSLBitRange_3
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> clk
portDecl child 
bitrange
ID----------> *CSLBitRange_4
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
port
ID----------> clk1
portDecl child 
bitrange
ID----------> *CSLBitRange_5
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
portDecl child 
port END
interface child 
interface END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
expr link
expr link  child
expr link END
unit END
unit decl
ID----------> stim_vec
interface
ID----------> *stim_vec_default_ifc
interface child 
interface END
unit END
unit decl
ID----------> exp_vec
interface
ID----------> *exp_vec_default_ifc
interface child 
interface END
unit END
unit decl
ID----------> tb
interface
ID----------> *tb_default_ifc
interface child 
interface END
signal
ID----------> clk
bitrange
ID----------> *CSLBitRange_7
simpleBitRange child 1
====number
simpleBitRange child 2
====number
simpleBitRange child 3
====number
exprOp
exprOp
====number
exprOp - child
====number
exprOp - child
ExprOp END
exprOp - child
====number
exprOp - child
ExprOp END
simpleBitRange child 4
bit range END
signal END
expr link
expr link  child
expr link END
ID----------> dut_1
unit END
