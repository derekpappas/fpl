#include "exp_vec.h"

namespace NSCsimGen {

void exp_vec::defaultInitialize(RefCsimUnit unit) {
      exp_d = CsimPortTBool::build(RefString(new std::string("exp_d")),1, unit, PORT_DIR_OUTPUT);
      exp_v = CsimPortTBool::build(RefString(new std::string("exp_v")),1, unit, PORT_DIR_OUTPUT);

}
void exp_vec::defaultConnect(RefCsimUnit associatedUnitInst) {
      exp_d->connect(boost::static_pointer_cast<CsimPortTBool>(associatedUnitInst->getSignalByName(RefString(new std::string("exp_d")))));
      exp_v->connect(boost::static_pointer_cast<CsimPortTBool>(associatedUnitInst->getSignalByName(RefString(new std::string("exp_v")))));

}
void exp_vec::writeVector(){
      TRadix dataRadix = getRadix();
      std::ofstream* outputStream = getOutputStream();

      (*outputStream) << *(convertValueTo(exp_d->getValue(), dataRadix, 1)) << "_";
      (*outputStream) << *(convertValueTo(exp_v->getValue(), dataRadix, 1)) <<  std::endl;

}
}
