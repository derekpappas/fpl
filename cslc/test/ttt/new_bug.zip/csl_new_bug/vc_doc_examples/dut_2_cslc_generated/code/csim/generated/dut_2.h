#ifndef DUT_2_H
#define DUT_2_H

#include "/home/oanab/svn/trunk/src/csim/CsimSignal.h"
#include "/home/oanab/svn/trunk/src/csim/CsimPort.h"
#include "stim_vec.h"
#include "exp_vec.h"

using namespace NSCsimLib;

namespace NSCsimGen {

class dut_2 : public CsimUnit {
public:
  RefCsimPortTBool stim_in;
  RefCsimPortTBool stim_v;
  RefCsimPortTBool exp_d;
  RefCsimPortTBool exp_v;
  RefCsimClock clk;
  RefCsimPortTBool clk1;
  RefCsimVectorWriter stim_vec0;
  RefCsimVectorWriter exp_vec0;
  //functions
  void defaultInitialize();
  void connect();
  virtual void allocate() = 0;
  virtual void initialize() = 0;
  virtual void execute() = 0;
  //constructor
  dut_2() : CsimUnit(RefString(new std::string("dut_2"))) {}
};
}

#endif
