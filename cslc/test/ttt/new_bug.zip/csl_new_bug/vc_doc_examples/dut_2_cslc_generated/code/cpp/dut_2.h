#ifndef INC_GUARD_dut_2_h
#define INC_GUARD_dut_2_h

const int P_STIM_IN_UPPER = 0;
const int P_STIM_IN_LOWER = 0;
const int P_STIM_IN_WIDTH = 0-0+1;

const int 0P_STIM_V_UPPER = 0;
const int P_STIM_V_LOWER = 0;
const int P_STIM_V_WIDTH = 0-0+1;

const int 0P_EXP_D_UPPER = 0;
const int P_EXP_D_LOWER = 0;
const int P_EXP_D_WIDTH = 0-0+1;

const int 0P_EXP_V_UPPER = 0;
const int P_EXP_V_LOWER = 0;
const int P_EXP_V_WIDTH = 0-0+1;

const int 0P_CLK_UPPER = 0;
const int P_CLK_LOWER = 0;
const int P_CLK_WIDTH = 0-0+1;

const int 0P_CLK1_UPPER = 0;
const int P_CLK1_LOWER = 0;
const int P_CLK1_WIDTH = 0-0+1;

clk1clkexp_dexp_vstim_vstim_in
#endif
