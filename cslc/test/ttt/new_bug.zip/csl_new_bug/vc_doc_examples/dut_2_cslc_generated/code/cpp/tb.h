#ifndef INC_GUARD_tb_h
#define INC_GUARD_tb_h

const int 0S_CLK_UPPER = 0;
const int S_CLK_LOWER = 0;
const int S_CLK_WIDTH = 0-0+1;

dut_2
#endif
