#ifndef STIM_VEC_H
#define STIM_VEC_H

#include "/home/oanab/svn/trunk/src/csim/CsimSignal.h"
#include "/home/oanab/svn/trunk/src/csim/CsimPort.h"
#include "/home/oanab/svn/trunk/src/csim/CsimVectorWriter.h"

using namespace NSCsimLib;

namespace NSCsimGen {

class stim_vec : public CsimVectorWriter {
  public:
    RefCsimPortTBool stim_in;
    RefCsimPortTBool stim_v;
    RefCsimPortTBool clk1;

    //functions
    void defaultInitialize(RefCsimUnit unit);
    void defaultConnect(RefCsimUnit associatedUnitInst);
    void writeVector();
    //constructor
    stim_vec() : CsimVectorWriter(0, 0, RefString(new std::string("stim_vec")), NSCsimLib::VECTOR_TYPE_STIM, NSCsimLib::T_BIN, 0) {}
};
}

#endif
