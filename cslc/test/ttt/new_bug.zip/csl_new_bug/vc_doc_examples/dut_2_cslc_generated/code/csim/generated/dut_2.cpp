#include "dut_2.h"

namespace NSCsimGen {

void dut_2::defaultInitialize() {
  setInstanceName(RefString(new std::string("dut_2")));
  //port allocations
  stim_in = CsimPortTBool::build(RefString(new std::string("stim_in")),1, getThis(), PORT_DIR_INPUT);
  stim_v = CsimPortTBool::build(RefString(new std::string("stim_v")),1, getThis(), PORT_DIR_INPUT);
  exp_d = CsimPortTBool::build(RefString(new std::string("exp_d")),1, getThis(), PORT_DIR_OUTPUT);
  exp_v = CsimPortTBool::build(RefString(new std::string("exp_v")),1, getThis(), PORT_DIR_OUTPUT);
  clk1 = CsimPortTBool::build(RefString(new std::string("clk1")),1, getThis(), PORT_DIR_INPUT);
  //port registrations
  addConnectable(stim_in);
  addConnectable(stim_v);
  addConnectable(exp_d);
  addConnectable(exp_v);
  addConnectable(clk1);
  //signal allocations
  clk = CsimClock::build(2, (RefString(new std::string("clk"))), getThis());
  //signal registrations
  //building vector writers
  stim_vec0 = buildVW(new stim_vec(), getThis());
  exp_vec0 = buildVW(new exp_vec(), getThis());
  //initializers
  allocate();
  connect();
  initialize();
}

void dut_2::connect() {
}
}
