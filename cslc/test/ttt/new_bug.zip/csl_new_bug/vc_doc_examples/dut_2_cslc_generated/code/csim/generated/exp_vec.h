#ifndef EXP_VEC_H
#define EXP_VEC_H

#include "/home/oanab/svn/trunk/src/csim/CsimSignal.h"
#include "/home/oanab/svn/trunk/src/csim/CsimPort.h"
#include "/home/oanab/svn/trunk/src/csim/CsimVectorWriter.h"

using namespace NSCsimLib;

namespace NSCsimGen {

class exp_vec : public CsimVectorWriter {
    public:
      RefCsimPortTBool exp_d;
      RefCsimPortTBool exp_v;

      //functions
      void defaultInitialize(RefCsimUnit unit);
      void defaultConnect(RefCsimUnit associatedUnitInst);
      void writeVector();
      //constructor
      exp_vec() : CsimVectorWriter(0, 0, RefString(new std::string("exp_vec")), NSCsimLib::VECTOR_TYPE_EXPECT, NSCsimLib::T_BIN, 0) {}
};
}

#endif
