#ifndef INC_GUARD_stim_vec_h
#define INC_GUARD_stim_vec_h


#endif
