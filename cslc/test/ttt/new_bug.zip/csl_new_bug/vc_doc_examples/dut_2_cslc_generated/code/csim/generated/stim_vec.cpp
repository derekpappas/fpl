#include "stim_vec.h"

namespace NSCsimGen {

void stim_vec::defaultInitialize(RefCsimUnit unit) {
    stim_in = CsimPortTBool::build(RefString(new std::string("stim_in")),1, unit, PORT_DIR_INPUT);
    stim_v = CsimPortTBool::build(RefString(new std::string("stim_v")),1, unit, PORT_DIR_INPUT);
    clk1 = CsimPortTBool::build(RefString(new std::string("clk1")),1, unit, PORT_DIR_INPUT);

}
void stim_vec::defaultConnect(RefCsimUnit associatedUnitInst) {
    stim_in->connect(boost::static_pointer_cast<CsimPortTBool>(associatedUnitInst->getSignalByName(RefString(new std::string("stim_in")))));
    stim_v->connect(boost::static_pointer_cast<CsimPortTBool>(associatedUnitInst->getSignalByName(RefString(new std::string("stim_v")))));
    clk1->connect(boost::static_pointer_cast<CsimPortTBool>(associatedUnitInst->getSignalByName(RefString(new std::string("clk1")))));

}
void stim_vec::writeVector(){
    TRadix dataRadix = getRadix();
    std::ofstream* outputStream = getOutputStream();

    (*outputStream) << *(convertValueTo(stim_in->getValue(), dataRadix, 1)) << "_";
    (*outputStream) << *(convertValueTo(stim_v->getValue(), dataRadix, 1)) << "_";
    (*outputStream) << *(convertValueTo(clk1->getValue(), dataRadix, 1)) <<  std::endl;

}
}
