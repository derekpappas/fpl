#!/bin/bash
./csl_test_gen.sh $* 2>&1 >/dev/null
echo "Done generating."
