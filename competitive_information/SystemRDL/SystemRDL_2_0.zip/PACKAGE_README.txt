=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
            SystemRDL Lanaguage Specification Package
        (c) 2006 by Denali Software, Inc.  All Rights reserved.
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

The blueprint distribution contains the following files and directories:

./README.txt        -- General information about the SystemRDL
                       Language Specification Package

./RELEASE_NOTES.txt -- Information on the revision history of
                       System RDL Language Specification Package


./SystemRDL_X_Y_Reference_Manual.pdf - The Specification in PDF

./SystemRDL.g             -- The Antlr grammar for SystemRDL

For Technical Support please submit request to:
        http://www.denali.com/support

