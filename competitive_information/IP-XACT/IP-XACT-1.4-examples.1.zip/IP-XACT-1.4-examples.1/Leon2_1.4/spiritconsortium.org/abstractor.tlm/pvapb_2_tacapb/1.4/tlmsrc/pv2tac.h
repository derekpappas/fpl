/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                    SPIRIT 1.4 OSCI-TLM-PV to TAC example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM PV to TAC converter
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2007
 *******************************************************************************/

#ifndef _PV2TAC_H_
#define _PV2TAC_H_

#include <systemc.h>
#include "pv_slave_base.h"
#include "pv_target_port.h"
#include "user_types.h"
#include "tlm_host_def.h"

class pv2tac : 
  public sc_module,
  public pv_slave_base< ADDRESS_TYPE , DATA_TYPE >
{
public:
  SC_HAS_PROCESS(pv2tac);
  pv2tac( sc_module_name module_name );
  ~pv2tac();

  pv_target_port<ADDRESS_TYPE,DATA_TYPE>    tlmpv_slave_port;
  prt_tlm_tac::tac_initiator_port<tlm_uint32_t,tlm_uint32_t> tac_master_port;

  tlm::tlm_status write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			 const unsigned int byte_enable = tlm::NO_BE,
			 const tlm::tlm_mode mode = tlm::REGULAR,
			 const unsigned int export_id = 0 );
  tlm::tlm_status read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			const unsigned int byte_enable = tlm::NO_BE,
			const tlm::tlm_mode mode = tlm::REGULAR,
			const unsigned int export_id = 0 );
  
private:
  void end_of_elaboration();
} 

#endif
