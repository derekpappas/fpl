// Copyright (c) 2005, 2006, 2007 The SPIRIT Consortium.  All rights reserved.
// www.spiritconsortium.org
//
// THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.
// USE OF THESE MATERIALS ARE GOVERNED BY
// THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE SPIRIT
// SPECIFICATION DISCLAIMER AVAILABLE FROM
// www.spiritconsortium.org
//
// This source file is provided on an AS IS basis. The SPIRIT Consortium disclaims 
// ANY WARRANTY EXPRESS OR IMPLIED INCLUDING ANY WARRANTY OF
// MERCHANTABILITY AND FITNESS FOR USE FOR A PARTICULAR PURPOSE. 
// The user of the source file shall indemnify and hold The SPIRIT Consortium harmless
// from any damages or liability arising out of the use thereof or the performance or
// implementation or partial implementation of the schema.

/*------------------------------------------------------------------------------
 * Simple Leon2 TLM AHBram memory
 *------------------------------------------------------------------------------*/

#ifndef _AHBRAM_H_
#define _AHBRAM_H_

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include <systemc.h>
#include "pv_slave_base.h"
#include "pv_target_port.h"
#include "user_types.h"

/*------------------------------------------------------------------------------
 * Define device parameters
 *----------------------------------------------------------------------------*/
#define MEM_BASE_ADDR     0x0
#define MEM_SIZE          0x01000000 // 16Mb

/*------------------------------------------------------------------------------
 * leon2 ahbram
 *----------------------------------------------------------------------------*/

class ahbram :
  public sc_module ,
  public pv_slave_base< ADDRESS_TYPE , DATA_TYPE >
{
public:
  SC_HAS_PROCESS(ahbram);
  ahbram( sc_module_name module_name , unsigned long memsize = MEM_SIZE);
  ~ahbram();

  pv_target_port<ADDRESS_TYPE , DATA_TYPE> ahb_slave_port;

  tlm::tlm_status write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			 const unsigned int byte_enable = tlm::NO_BE,
			 const tlm::tlm_mode mode = tlm::REGULAR,
			 const unsigned int export_id = 0 );
  tlm::tlm_status read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			const unsigned int byte_enable = tlm::NO_BE,
			const tlm::tlm_mode mode = tlm::REGULAR,
			const unsigned int export_id = 0 );
  
private:
  void end_of_elaboration();
  sc_pvector<DATA_TYPE> memory;
  void init_memory(unsigned long s);
};


#endif /* _AHBRAM_H_ */
