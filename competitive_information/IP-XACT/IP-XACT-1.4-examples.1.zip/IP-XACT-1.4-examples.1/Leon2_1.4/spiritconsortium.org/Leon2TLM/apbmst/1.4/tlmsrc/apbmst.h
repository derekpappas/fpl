// Copyright (c) 2005, 2006, 2007 The SPIRIT Consortium.  All rights reserved.
// www.spiritconsortium.org
//
// THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.
// USE OF THESE MATERIALS ARE GOVERNED BY
// THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE SPIRIT
// SPECIFICATION DISCLAIMER AVAILABLE FROM
// www.spiritconsortium.org
//
// This source file is provided on an AS IS basis. The SPIRIT Consortium disclaims 
// ANY WARRANTY EXPRESS OR IMPLIED INCLUDING ANY WARRANTY OF
// MERCHANTABILITY AND FITNESS FOR USE FOR A PARTICULAR PURPOSE. 
// The user of the source file shall indemnify and hold The SPIRIT Consortium harmless
// from any damages or liability arising out of the use thereof or the performance or
// implementation or partial implementation of the schema.

 /*------------------------------------------------------------------------------
 * Simple Leon2 TLM AHB to APB bridge
 *------------------------------------------------------------------------------*/

#ifndef __APBMST_H__
#define __APBMST_H__

#include <systemc.h>
#include "pv_router.h"
#include "user_types.h"

typedef pv_router< ADDRESS_TYPE , DATA_TYPE > basic_router;


class apbmst : public basic_router
{
 public:
  apbmst (sc_module_name module_name, const char* mapFile)
    : basic_router (module_name, mapFile)
  {}
  void end_of_elaboration() {
    basic_router::end_of_elaboration();
    cout << name() << " constructed." << endl;
  }
};


#endif
