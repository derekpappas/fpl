/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM timers
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2007
 *******************************************************************************/

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include "timers.h"

/*------------------------------------------------------------------------------
 * Methods
 *----------------------------------------------------------------------------*/
timers::timers( sc_module_name module_name , int k ) :
  sc_module( module_name ),
  pv_slave_base<ADDRESS_TYPE,DATA_TYPE>(name()),
  apb_slave_port("apb_slave_port"),
  int0("int0"),
  int1("int1")
{
  apb_slave_port( *this );
  int0.initialize(false);
  int1.initialize(false);
  init_registers(k);
  SC_METHOD(count); // timer process
  dont_initialize();
}

timers::~timers() {
}

void timers::end_of_elaboration() {
  cout << name() << " constructed." << endl;
}

tlm::tlm_status timers::write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			       const unsigned int byte_enable,
			       const tlm::tlm_mode mode,
			       const unsigned int export_id)
{
  tlm::tlm_status status;
  if ((addr < TIMER_BASE_ADDR) || (addr >= TIMER_BASE_ADDR+TIMER_SIZE)) {
    cout << "ERROR\t" << name() << " : trying to write out of bounds at address " << addr << endl;
    status.set_error();
    return status;
  }
  registers[addr] = data;
  if ( addr==TIMER0_CONTROL && data==TIMER_DISABLED) {
    cout << name() << " Timer0 disabled (clear control register0)" << endl;
    // Reset timer interrupt signal value 
    int0.write(0);
  }
  if ( addr==TIMER1_CONTROL && data==TIMER_DISABLED) {
    cout << name() << " Timer1 disabled (clear control register1)" << endl;
    int1.write(0);
  }
  status.set_ok();
  return status;
}

tlm::tlm_status timers::read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			      const unsigned int byte_enable,
			      const tlm::tlm_mode mode,
			      const unsigned int export_id)
{
  tlm::tlm_status status;
  if ((addr < TIMER_BASE_ADDR) || (addr >= TIMER_BASE_ADDR+TIMER_SIZE)) {
    cout << "ERROR\t" << name() << " : trying to read out of bounds at address " << addr << endl;
    status.set_error();
    return status;
  }
  data = registers[addr];
  status.set_ok();
  return status;
}

void timers::init_registers(int k) 
{
  for (int i=0; i < k; i++) registers[i]=0;
}

void timers::count() 
{
  if ((registers[TIMER0_COUNTER] > 0) &&
      (registers[TIMER0_CONTROL]==TIMER_ENABLED)) {
    cout << "... T0=" << registers[TIMER0_COUNTER] << endl;
    registers[TIMER0_COUNTER]--;
    if (registers[TIMER0_COUNTER] == 0) {
      int0.write(1);
    }
  }
  if ((registers[TIMER1_COUNTER] > 0) &&
      (registers[TIMER1_CONTROL]==TIMER_ENABLED)) {
    cout << "... T1=" << registers[TIMER1_COUNTER] << endl;
    registers[TIMER1_COUNTER]--;
    if (registers[TIMER1_COUNTER] == 0) {
      int1.write(1);
    }
  }
  // Timer count rate ( SC kernel recall this method when simulation time
  // reaches now + 10 ns
  next_trigger(10,SC_NS);
}
