/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple TLM APB design
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2006
 *******************************************************************************/

#ifndef _APB_SUBSYSTEM_H_
#define _APB_SUBSYSTEM_H_

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include <systemc.h>

#include "apbbus.h"
#include "apbmst.h"
#include "timers.h"
#include "irqctrl.h"
#include "user_types.h"

#include "pv_target_port.h"
#include "pv_initiator_port.h"

/*------------------------------------------------------------------------------
 *  top netlist
 *----------------------------------------------------------------------------*/
class apb_subsystem : public sc_module
{
 public:
  // slave ports
  sc_in<int>                 int4_slave_port;
  pv_target_port<ADDRESS_TYPE,DATA_TYPE>    ahb_slave_port;
  // interrupt ports
  sc_out<int>        irl_master_port;
  sc_in<sc_lv<4> >   irq_slave_port;
  sc_in<bool>        ack_slave_port;

  pv_initiator_port<ADDRESS_TYPE,DATA_TYPE> apb4_mslave_port;
  pv_initiator_port<ADDRESS_TYPE,DATA_TYPE> apb5_mslave_port;
  pv_initiator_port<ADDRESS_TYPE,DATA_TYPE> apb6_mslave_port;
  pv_initiator_port<ADDRESS_TYPE,DATA_TYPE> apb7_mslave_port;

 private:
  // component instances
  apbmst*  i_h2p;
  apbbus*  i_apb;
  irqctrl* i_irq;
  timers*  i_tim;
  // interrupt signals
  sc_buffer<int>  interrupt_tim0;
  sc_buffer<int>  interrupt_tim1;
  sc_buffer<int>  dangling;

 public:
  apb_subsystem(sc_module_name module_name) : sc_module(module_name),
    ahb_slave_port("ahb_slave_port"),
    apb4_mslave_port("apb4_mslave_port"),
    apb5_mslave_port("apb5_mslave_port"),
    apb6_mslave_port("apb6_mslave_port"),
    apb7_mslave_port("apb7_mslave_port")
    {
      // instances
      i_h2p = new apbmst("BRIDGE","leon2ApbMst.map");
      i_apb = new apbbus("APBbus","leon2ApbBus.map");
      i_irq = new irqctrl("IRQCTR");
      i_tim = new timers("TIMERS");
      // interconnections (transactional port binding)
      i_h2p->initiator_port ( i_apb->target_port );
      i_apb->initiator_port ( i_irq->apb_slave_port ); // binding of APB 0
      i_apb->initiator_port ( i_tim->apb_slave_port ); // binding of APB 1
      // adhoc connections (wire port binding)
      i_tim->int0 (interrupt_tim0);
      i_irq->int3 (interrupt_tim0);
      i_tim->int1 (interrupt_tim1);
      i_irq->int2 (interrupt_tim1);
      i_irq->int1 (dangling);
      i_irq->int0 (dangling);
      // external interconnections 
      ahb_slave_port (i_h2p->target_port );
      i_apb->initiator_port ( apb7_mslave_port ); // binding of APB 7
      i_apb->initiator_port ( apb6_mslave_port ); // binding of APB 6
      i_apb->initiator_port ( apb5_mslave_port ); // binding of APB 5
      i_apb->initiator_port ( apb4_mslave_port ); // binding of APB 4
      // external adhoc connections
      i_irq->int4 ( this->int4_slave_port );
      i_irq->irlout ( this->irl_master_port );
      i_irq->irlin  ( this->irq_slave_port );
      i_irq->intack ( this->ack_slave_port );
    }
  ~apb_subsystem() {
    delete i_h2p;
    delete i_apb;
    delete i_tim;
    delete i_irq;
  }
};

#endif /* _APB_SUBSYSTEM_H_ */


