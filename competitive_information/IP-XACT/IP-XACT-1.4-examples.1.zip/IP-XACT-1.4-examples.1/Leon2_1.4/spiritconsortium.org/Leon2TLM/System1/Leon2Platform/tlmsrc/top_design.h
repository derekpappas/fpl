/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple TLM Design netlist
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2006
 *******************************************************************************/

#ifndef _TOP_DESIGN_H_
#define _TOP_DESIGN_H_

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include <systemc.h>

#include "processor.h"
#include "ahbram.h"
#include "ahbbus.h"
#include "apb_subsystem.h"
#include "dma.h"
#include "cgu.h"
#include "rgu.h"

/*------------------------------------------------------------------------------
 *  top netlist
 *----------------------------------------------------------------------------*/
class top_design : public sc_module
{
 private:
  // component instances
  processor*     i_proc; 
  ahbram*        i_mem;
  ahbbus*        i_ahb;
  apb_subsystem* i_sub;
  dma*        i_dma;
  cgu*           i_cgu;
  rgu*           i_rgu;
  // interrupt signals
  sc_buffer<int>        interrupt_proc_irl;
  sc_buffer<sc_lv<4> >  interrupt_proc_irq;
  sc_buffer<bool>       interrupt_proc_ack;
  sc_buffer<int>        interrupt_dma;
  // clock and reset signals
  sc_clock clk;
  sc_buffer<sc_logic> rst;
  sc_buffer<sc_lv<8> > rstdiv;
  sc_buffer<sc_lv<8> > clkdiv;


 public:
  // Note: the timers and memory size and base addresses 
  //       (start addr, end addr) are defined in in each 
  //       component external map files.
  top_design(sc_module_name module_name) : sc_module(module_name), clk("clk",20,SC_NS)
  {
      // instances
      i_proc = new processor("PROC","master.tbl");
      i_mem = new ahbram("MEM");
      i_ahb = new ahbbus("AHBbus","leon2AhbBus.map");
      i_sub = new apb_subsystem("APBsubsystem");
      i_dma = new dma("DMA");
      i_cgu = new cgu("CGU");
      i_rgu = new rgu("RGU");
      // interconnections (transactional port binding)
      i_proc->ahb_master_port ( i_ahb->target_port );
      i_dma->ahb_master_port ( i_ahb->target_port );
      i_ahb->initiator_port ( i_mem->ahb_slave_port );
      i_ahb->initiator_port ( i_sub->ahb_slave_port );
      i_sub->apb4_mslave_port ( i_cgu->apb_slave_port );
      i_sub->apb5_mslave_port ( i_rgu->apb_slave_port );
      i_sub->apb6_mslave_port ( i_proc->apb_slave_port );
      i_sub->apb7_mslave_port ( i_dma->apb_slave_port );
      // adhoc connections (wire port binding)
      i_proc->irl_port (interrupt_proc_irl);
      i_proc->irqvec_port (interrupt_proc_irq);
      i_proc->intack_port (interrupt_proc_ack);
      i_sub->irl_master_port (interrupt_proc_irl);
      i_sub->irq_slave_port (interrupt_proc_irq);
      i_sub->ack_slave_port (interrupt_proc_ack);
      i_dma->int_master_port (interrupt_dma);
      i_sub->int4_slave_port (interrupt_dma);
      i_cgu->clkin(clk);
      i_cgu->clkout(clkdiv);
      i_rgu->ipclk(clk);
      i_rgu->rstin_an(rst);
      i_rgu->rstout_an(rstdiv);
    }
  ~top_design() {
    delete i_proc;
    delete i_mem;
    delete i_ahb;
    delete i_dma;
    delete i_sub;
    delete i_cgu;
    delete i_rgu;
  }
};

#endif /* _TOP_DESIGN_H_ */


