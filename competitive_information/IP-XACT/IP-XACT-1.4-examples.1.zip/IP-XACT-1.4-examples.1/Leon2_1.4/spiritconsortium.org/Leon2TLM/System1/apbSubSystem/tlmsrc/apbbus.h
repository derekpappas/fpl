/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM APB bus
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2007
 *******************************************************************************/

#ifndef __APBBUS_H__
#define __APBBUS_H__

#include <systemc.h>
#include "pv_router.h"
#include "user_types.h"

typedef pv_router< ADDRESS_TYPE , DATA_TYPE > basic_router;


// this class has 1 target port (target_port) and 8 initiator ports (r_port[x])
// the number of initiator ports is computed at elaboration time (based on 
// this bus interconnection).
class apbbus : public basic_router
{
 public:
  apbbus (sc_module_name module_name,  const char* mapFile)
    : basic_router (module_name, mapFile)
  {}
  void end_of_elaboration() {
    basic_router::end_of_elaboration();
    cout << name() << " constructed." << endl;
  }
};

#endif
