#ifndef _USER_TYPES_H_
#define _USER_TYPES_H_

typedef int ADDRESS_TYPE;
typedef int DATA_TYPE;
typedef int LOGIC;
#define LOGIC_0 0
#define LOGIC_1 1
#define CLOCK_CYCLE 10

#endif /* _USER_TYPES_H_ */
