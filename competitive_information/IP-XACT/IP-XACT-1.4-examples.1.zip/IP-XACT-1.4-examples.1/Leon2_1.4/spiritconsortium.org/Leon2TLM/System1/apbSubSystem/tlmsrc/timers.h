/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM timers
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2007
 *******************************************************************************/

#ifndef _TIMERS_H_
#define _TIMERS_H_

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include <systemc.h>

#include "pv_slave_base.h"
#include "pv_target_port.h"
#include "user_types.h"


/*------------------------------------------------------------------------------
 * Define device parameters
 *----------------------------------------------------------------------------*/
#define TIMER_BASE_ADDR     0x0000 // in global systems, start at: 0x30001000
#define TIMER_SIZE          0x1000 // 4Kb

/*------------------------------------------------------------------------------
 * Define Timer Registers
 * Note : here static, but could be read from external description
 *----------------------------------------------------------------------------*/

#define TIMER_REGISTER_SIZE     0x4 // in bytes
#define TIMER0_COUNTER          TIMER_BASE_ADDR
#define TIMER0_RELOAD           TIMER_BASE_ADDR + 1*TIMER_REGISTER_SIZE
#define TIMER0_CONTROL          TIMER_BASE_ADDR + 2*TIMER_REGISTER_SIZE
#define WATCHDOG_COUNTER        TIMER_BASE_ADDR + 3*TIMER_REGISTER_SIZE
#define TIMER1_COUNTER          TIMER_BASE_ADDR + 4*TIMER_REGISTER_SIZE
#define TIMER1_RELOAD           TIMER_BASE_ADDR + 5*TIMER_REGISTER_SIZE
#define TIMER1_CONTROL          TIMER_BASE_ADDR + 6*TIMER_REGISTER_SIZE
#define PRESCALER_COUNTER       TIMER_BASE_ADDR + 7*TIMER_REGISTER_SIZE
#define PRESCALER_RELOAD_VALUE  TIMER_BASE_ADDR + 8*TIMER_REGISTER_SIZE

#define TIMER_CLEAR         1
#define TIMER_LOAD          2
#define TIMER_CTRL          3
#define TIMER_DISABLED      0
#define TIMER_ENABLED       1

/*------------------------------------------------------------------------------
 * leon2 timers
 *----------------------------------------------------------------------------*/

class timers :
  public sc_module ,
  public pv_slave_base< ADDRESS_TYPE , DATA_TYPE >
{
public:
  SC_HAS_PROCESS(timers);
  timers( sc_module_name module_name , int k = 9 );
  ~timers();

  pv_target_port<ADDRESS_TYPE,DATA_TYPE>    apb_slave_port;
  sc_out<int>		int0;
  sc_out<int>		int1;

  tlm::tlm_status write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			 const unsigned int byte_enable = tlm::NO_BE,
			 const tlm::tlm_mode mode = tlm::REGULAR,
			 const unsigned int export_id = 0 );
  tlm::tlm_status read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			const unsigned int byte_enable = tlm::NO_BE,
			const tlm::tlm_mode mode = tlm::REGULAR,
			const unsigned int export_id = 0 );

private:
  sc_pvector<DATA_TYPE> registers;
  void init_registers(int k);
  void count();
  void end_of_elaboration();
};

#endif /* _TIMERS_H_ */
