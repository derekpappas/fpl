/*---------------------------------------------------------------------------
 * Copyright (c) 2006 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM AHBram memory
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2006
 *******************************************************************************/

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include "ahbram.h"


/*------------------------------------------------------------------------------
 * Methods
 *----------------------------------------------------------------------------*/
ahbram::ahbram( sc_module_name module_name , unsigned long memsize ) :
  sc_module( module_name ),
  pv_slave_base<ADDRESS_TYPE,DATA_TYPE>(name()),
  ahb_slave_port("ahb_slave_port"),
  memory(memsize)
{
  ahb_slave_port( *this );
  init_memory(memsize);
}

ahbram::~ahbram() {
}

void ahbram::end_of_elaboration() {
  cout << name() << " constructed." << endl;
}

tlm::tlm_status ahbram::write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			       const unsigned int byte_enable,
			       const tlm::tlm_mode mode,
			       const unsigned int export_id)
{
  tlm::tlm_status status;
  if ((addr < MEM_BASE_ADDR) || (addr >= MEM_BASE_ADDR+MEM_SIZE)) {
    cout << "ERROR\t" << name() << " : trying to write out of bounds at address " << addr << endl;
    status.set_error();
    return status;
  }
  memory[addr] = data;
  status.set_ok();
  return status;
}

tlm::tlm_status ahbram::read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			      const unsigned int byte_enable,
			      const tlm::tlm_mode mode,
			      const unsigned int export_id)
{
  tlm::tlm_status status;
  if ((addr < MEM_BASE_ADDR) || (addr >= MEM_BASE_ADDR+MEM_SIZE)) {
    cout << "ERROR\t" << name() << " : trying to read out of bounds at address " << addr << endl;
    status.set_error();
    return status;
  }
  data = memory[addr];
  status.set_ok();
  return status;
}

void ahbram::init_memory(unsigned long s) 
{
  for (unsigned long i=0; i < s; i++) memory[i]=1;
}

