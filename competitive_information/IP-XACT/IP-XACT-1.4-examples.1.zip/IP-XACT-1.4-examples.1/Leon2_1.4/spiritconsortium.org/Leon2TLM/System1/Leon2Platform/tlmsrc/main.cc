/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM Design main
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2006
 *******************************************************************************/

#include "top_design.h"

int sc_main( int argc , char **argv ) {
  top_design top("top_TLM");
  sc_start( 1 , SC_MS );
  return 0;
}
