/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple TLM RGU
 * Clock diviser PV example. Produces a clock vector of 8 bits.
 * Each Clock output line has a 8 bits devide register.
 * If register[i]=0 => No divide (reset state)
 * If register[i]=1 => divide by 2 
 * If register[i]=2 => divide by 4 
 * If register[i]=3 => divide by 8 ...
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2007
 *******************************************************************************/

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include "rgu.h"

/*------------------------------------------------------------------------------
 * Methods
 *----------------------------------------------------------------------------*/
rgu::rgu( sc_module_name module_name) :
  sc_module( module_name ) , 
  pv_slave_base<ADDRESS_TYPE,DATA_TYPE>(name()),
  apb_slave_port ("apb_slave_port"),
  ipclk ("ipclk"),
  rstin_an ("rstin"),
  rstout_an ("rstout")
{
  apb_slave_port( *this );
  SC_METHOD( gen_resets );
  sensitive << ipclk.pos();
  init_registers();
  init_memory();
}

tlm::tlm_status rgu::write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			    const unsigned int byte_enable,
			    const tlm::tlm_mode mode,
			    const unsigned int export_id )
{
  tlm::tlm_status status;
  if ((addr/4) < NUMRESETS) {
    registers[addr/4] = data;
  } else if ((addr/4) < NUMRESETS + DELAYDEPTH) {
    memory[addr/4] = data;
  }
  status.set_ok();
  return status;
}

tlm::tlm_status rgu::read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			   const unsigned int byte_enable,
			   const tlm::tlm_mode mode,
			   const unsigned int export_id )
{
  tlm::tlm_status status;
  if ((addr/4) < NUMRESETS) { // read the registers
    data = registers[addr/4];
  } else if (addr < NUMRESETS + DELAYDEPTH) { 
    data = memory[addr/4]; // read the memory registers
  } else if (addr == 0xFFC) { // read the ID register
    data = 0xD01;
  } else {
    data = 0x0;
  }
  status.set_ok();
  return status;
}

void rgu::gen_resets()
{
  if (rstin_an==0) {
    for (int i=0; i<NUMRESETS; i++) rstout_an.write(0);
  } else {
    for (int i=0; i<NUMRESETS; i++) {
      if (registers[i] == 0) rstout_an.write(0);
      else                   rstout_an.write(1);;
    }
  }
}

void rgu::init_registers()
{
 for (int i=0;i<NUMRESETS;i++) registers[i]=0;
}

void rgu::init_memory()
{
 for (int i=0;i<NUMRESETS;i++) memory[i]=0;
}
