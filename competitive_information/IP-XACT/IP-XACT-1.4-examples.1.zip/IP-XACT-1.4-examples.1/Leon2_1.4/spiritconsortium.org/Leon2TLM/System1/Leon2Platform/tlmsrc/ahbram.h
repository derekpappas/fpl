/*---------------------------------------------------------------------------
 * Copyright (c) 2006 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple Leon2 TLM AHBram memory
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 * Copyright The SPIRIT Consortium 2006
 *******************************************************************************/

#ifndef _AHBRAM_H_
#define _AHBRAM_H_

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include <systemc.h>
#include "pv_slave_base.h"
#include "pv_target_port.h"
#include "user_types.h"

/*------------------------------------------------------------------------------
 * Define device parameters
 *----------------------------------------------------------------------------*/
#define MEM_BASE_ADDR     0x0
#define MEM_SIZE          0x01000000 // 16Mb

/*------------------------------------------------------------------------------
 * leon2 ahbram
 *----------------------------------------------------------------------------*/

class ahbram :
  public sc_module ,
  public pv_slave_base< ADDRESS_TYPE , DATA_TYPE >
{
public:
  SC_HAS_PROCESS(ahbram);
  ahbram( sc_module_name module_name , unsigned long memsize = MEM_SIZE);
  ~ahbram();

  pv_target_port<ADDRESS_TYPE , DATA_TYPE> ahb_slave_port;

  tlm::tlm_status write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			 const unsigned int byte_enable = tlm::NO_BE,
			 const tlm::tlm_mode mode = tlm::REGULAR,
			 const unsigned int export_id = 0 );
  tlm::tlm_status read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			const unsigned int byte_enable = tlm::NO_BE,
			const tlm::tlm_mode mode = tlm::REGULAR,
			const unsigned int export_id = 0 );
  
private:
  void end_of_elaboration();
  sc_pvector<DATA_TYPE> memory;
  void init_memory(unsigned long s);
};


#endif /* _AHBRAM_H_ */
