/*---------------------------------------------------------------------------
 * Copyright (c) 2007 SPIRIT.  All rights reserved.
 * www.spiritconsortium.com
 * 
 * THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.  
 * THIS WORK CONTAINS TRADE SECRETS AND PROPRIETARY INFORMATION 
 * WHICH IS THE EXCLUSIVE PROPERTY OF INDIVIDUAL MEMBERS OF THE 
 * SPIRIT CONSORTIUM. USE OF THESE MATERIALS ARE GOVERNED BY 
 * THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE THE SPIRIT 
 * SPECIFICATION DISCLAIMER AVAILABLE FROM
 * www.spiritconsortium.org
 *---------------------------------------------------------------------------*/

/*******************************************************************************
 *                      SPIRIT 1.4 OSCI-TLM-PV example
 *------------------------------------------------------------------------------
 * Simple TLM DMA
 * The following code is derived, directly or indirectly, from the SystemC
 * source code Copyright (c) 1996-2006 by all Contributors.
 * All Rights reserved.
 *------------------------------------------------------------------------------
 * Revision: 1.4
 * Authors:  Jean-Michel Fernandez
 *******************************************************************************/

#ifndef _DMA_H_
#define _DMA_H_

/*------------------------------------------------------------------------------
 * Includes
 *----------------------------------------------------------------------------*/ 
#include "systemc.h"
#include "pv_slave_base.h"
#include "pv_target_port.h"
#include "pv_initiator_port.h"
#include "user_types.h"

//------------------------------------------------------------------------------
class dma : 
  public sc_module,
  public pv_slave_base< ADDRESS_TYPE , DATA_TYPE >
{
public :

  // Registers relative addresses
  static const int SRC_ADDR  = 0x0000;  
  static const int DST_ADDR  = 0x0004; 
  static const int CONTROL   = 0x0008; 
  // hardcoded lenght of the block transfer
  static const int LENGTH    = 0x001F; 
  
  // Control register bits
  static const int START = 0x1000;
  static const int IRQ   = 0x0010;


  //---------------
  // Module ports
  //---------------
  pv_target_port<ADDRESS_TYPE , DATA_TYPE> apb_slave_port;
  pv_initiator_port<ADDRESS_TYPE , DATA_TYPE> ahb_master_port;
  sc_out<int> int_master_port;

  //----------------
  // Constructor
  //----------------  
  SC_HAS_PROCESS(dma);
  dma(sc_module_name module_name,
	 tlm::tlm_endianness endian = TLM_HOST_ENDIAN);

  //--------------------------------------------------------------------------------------------
  //Abstract class pv_if methods implementation (overides pv_slave_base default implementation)
  //--------------------------------------------------------------------------------------------
  
  tlm::tlm_status write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			 const unsigned int byte_enable = tlm::NO_BE,
			 const tlm::tlm_mode mode = tlm::REGULAR,
			 const unsigned int export_id = 0 );
  tlm::tlm_status read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			const unsigned int byte_enable = tlm::NO_BE,
			const tlm::tlm_mode mode = tlm::REGULAR,
			const unsigned int export_id = 0 );


protected:
  
  tlm::tlm_endianness m_endian;       // dma endianness    
  sc_event m_start_transfer;          // dma process related event (start)
  sc_event m_irq_to_change;           // rise/clear interrupt signal related event
  ADDRESS_TYPE m_dma_src_addr;       // Source address register
  ADDRESS_TYPE m_dma_dst_addr;       // Destination address register
  tlm::tlm_uint8_t m_dma_control;  // control register (8 bits register)    
  
  void transfer();                    // dma transfer management process 
  void irq();                         // dma transfer end IRQ signal management process
};

#endif /* _DMA_H_ */


