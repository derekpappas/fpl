// Copyright (c) 2005, 2006, 2007 The SPIRIT Consortium.  All rights reserved.
// www.spiritconsortium.org
//
// THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.
// USE OF THESE MATERIALS ARE GOVERNED BY
// THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE SPIRIT
// SPECIFICATION DISCLAIMER AVAILABLE FROM
// www.spiritconsortium.org
//
// This source file is provided on an AS IS basis. The SPIRIT Consortium disclaims 
// ANY WARRANTY EXPRESS OR IMPLIED INCLUDING ANY WARRANTY OF
// MERCHANTABILITY AND FITNESS FOR USE FOR A PARTICULAR PURPOSE. 
// The user of the source file shall indemnify and hold The SPIRIT Consortium harmless
// from any damages or liability arising out of the use thereof or the performance or
// implementation or partial implementation of the schema.

/*------------------------------------------------------------------------------
 * Simple TLM RGU
 * Reset delay generator PV example. Produces a reset vector of 8 bits.
 * Each reset output line has a 8 bits delay register.
 * reset(0) = read only delay at address 0x0
 * reset(1) = read only delay at address 0x4
 * reset(2) = read only delay at address 0x8
 * reset(3) = read only delay at address 0xC
 * reset(4) = read only delay at address 0x10
 * reset(5) = read only delay at address 0x14
 * reset(6) = read only delay at address 0x18
 * reset(7) = read only delay at address 0x1C
 * The delay value (stored in the above reset registers) is the number 
 * of clocks from when the reset input is deasserted  till the 
 * reset output is deasserted. i.e.
 * 0 = No Delay 
 * 1 = Delay by 1 clock
 * 2 = Delay by 2 clocks
 * 3 = Delay by 3 clocks ...
 * The 8 other registers are used as non volatile storage inside the RGU
 * memory[0] = read/write register at address 0x20
 * memory[1] = read/write register at address 0x24
 * memory[2] = read/write register at address 0x28
 * ...
 * memory[7] = read/write register at address 0x3C
 * 4K byte addressSpace.
 *------------------------------------------------------------------------------*/

#ifndef _RGU_H_
#define _RGU_H_

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include <systemc.h>

#include "user_types.h"
#include "pv_target_port.h"
#include "pv_slave_base.h"

#define NUMRESETS 8
#define DELAYDEPTH 8
#define delay0 0
#define delay1 1
#define delay2 2
#define delay3 4
#define delay4 8
#define delay5 16
#define delay6 32
#define delay7 64

/*------------------------------------------------------------------------------
 * RGU 
 *----------------------------------------------------------------------------*/
class rgu :
   public sc_module,
   public pv_slave_base< ADDRESS_TYPE , DATA_TYPE >
{
 public:
  rgu( sc_module_name module_name);
  SC_HAS_PROCESS( rgu );
  
  pv_target_port<ADDRESS_TYPE , DATA_TYPE> apb_slave_port;
  sc_in<sc_logic>        rstin_an;
  sc_out <sc_lv <8> >    rstout_an;
  sc_in<bool>        ipclk;
  
  tlm::tlm_status write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			 const unsigned int byte_enable = tlm::NO_BE,
			 const tlm::tlm_mode mode = tlm::REGULAR,
			 const unsigned int export_id = 0 );
  tlm::tlm_status read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			const unsigned int byte_enable = tlm::NO_BE,
			const tlm::tlm_mode mode = tlm::REGULAR,
			const unsigned int export_id = 0 );

 private:
  sc_pvector<int> registers;
  sc_pvector<int> memory;
  void init_registers();
  void init_memory();
  void gen_resets();
};
 

#endif  /* _RGU_H_ */
