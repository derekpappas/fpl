// Copyright (c) 2005, 2006, 2007 The SPIRIT Consortium.  All rights reserved.
// www.spiritconsortium.org
//
// THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.
// USE OF THESE MATERIALS ARE GOVERNED BY
// THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE SPIRIT
// SPECIFICATION DISCLAIMER AVAILABLE FROM
// www.spiritconsortium.org
//
// This source file is provided on an AS IS basis. The SPIRIT Consortium disclaims 
// ANY WARRANTY EXPRESS OR IMPLIED INCLUDING ANY WARRANTY OF
// MERCHANTABILITY AND FITNESS FOR USE FOR A PARTICULAR PURPOSE. 
// The user of the source file shall indemnify and hold The SPIRIT Consortium harmless
// from any damages or liability arising out of the use thereof or the performance or
// implementation or partial implementation of the schema.

 /*------------------------------------------------------------------------------
 * Simple Leon2 TLM interrupt controller
 * Note: in this (dummy) implementation we only use a single register
 * to enable or disable the interrupts.
 *------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include "irqctrl.h"

/*------------------------------------------------------------------------------
 * Methods
 *----------------------------------------------------------------------------*/
irqctrl::irqctrl( sc_module_name module_name) :
  sc_module( module_name ),
  pv_slave_base<ADDRESS_TYPE,DATA_TYPE>(name()),
  irlout("irlout"),
  irlin("irlin"),
  intack("intack"),
  int0("int0"),
  int1("int1"),
  int2("int2"),
  int3("int3"),
  apb_slave_port("apb_slave_port")
{
  apb_slave_port( *this );
  init_register();
  SC_METHOD(run);
  dont_initialize();
  sensitive << int0;
  sensitive << int1;
  sensitive << int2;
  sensitive << int3;
  sensitive << int4;
  irlout.initialize(-1);
}

irqctrl::~irqctrl() {
}

tlm::tlm_status irqctrl::write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
				const unsigned int byte_enable,
				const tlm::tlm_mode mode,
				const unsigned int export_id)
{
  tlm::tlm_status status;

  if ((addr < IRQ_BASE_ADDR) || (addr >= IRQ_BASE_ADDR+IRQ_SIZE)) {
    cout << "ERROR\t" << name() << " : trying to write out of bounds at address " << addr << endl;
    status.set_error();
    return status;
  }
  if (data==IRQ_ENABLED) irq_register = IRQ_ENABLED;
  else irq_register = IRQ_DISABLED;
  status.set_ok();
  return status;
}

tlm::tlm_status irqctrl::read( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			      const unsigned int byte_enable,
			      const tlm::tlm_mode mode,
			      const unsigned int export_id)
{
  tlm::tlm_status status;
  if ((addr < IRQ_BASE_ADDR) || (addr >= IRQ_BASE_ADDR+IRQ_SIZE)) {
    cout << "ERROR\t" << name() << " : trying to read out of bounds at address " << addr << endl;
    status.set_error();
    return status;
  }
  data=irq_register;
  cout << name() << "    Read IRQ register value: " << data << endl; 
  status.set_ok();
  return status;
}

void irqctrl::end_of_elaboration() {
  cout << name() << " constructed." << endl;
}

void irqctrl::init_register()
{
  irq_register=IRQ_DISABLED;
}

void irqctrl::run() 
{
  if (irq_register==IRQ_ENABLED) {
    if (int0.read()==1)      irlout.write(0);
    else if (int1.read()==1) irlout.write(1);
    else if (int2.read()==1) irlout.write(2);
    else if (int3.read()==1) irlout.write(3);
    else if (int4.read()==1) irlout.write(4);
    else irlout.write(-1);
  }
}
