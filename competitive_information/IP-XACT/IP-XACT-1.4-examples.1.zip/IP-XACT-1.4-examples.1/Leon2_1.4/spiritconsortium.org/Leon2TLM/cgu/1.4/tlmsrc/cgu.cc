// Copyright (c) 2005, 2006, 2007 The SPIRIT Consortium.  All rights reserved.
// www.spiritconsortium.org
//
// THIS WORK FORMS PART OF A SPIRIT CONSORTIUM SPECIFICATION.
// USE OF THESE MATERIALS ARE GOVERNED BY
// THE LEGAL TERMS AND CONDITIONS OUTLINED IN THE SPIRIT
// SPECIFICATION DISCLAIMER AVAILABLE FROM
// www.spiritconsortium.org
//
// This source file is provided on an AS IS basis. The SPIRIT Consortium disclaims 
// ANY WARRANTY EXPRESS OR IMPLIED INCLUDING ANY WARRANTY OF
// MERCHANTABILITY AND FITNESS FOR USE FOR A PARTICULAR PURPOSE. 
// The user of the source file shall indemnify and hold The SPIRIT Consortium harmless
// from any damages or liability arising out of the use thereof or the performance or
// implementation or partial implementation of the schema.

 /*------------------------------------------------------------------------------
 * Simple TLM CGU
 * Clock diviser PV example. Produces a clock vector of 8 bits.
 * Each Clock output line has a 8 bits devide register.
 * If register[i]=0 => No divide (reset state)
 * If register[i]=1 => divide by 2 
 * If register[i]=2 => divide by 4 
 * If register[i]=3 => divide by 8 ...
 *------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
 * Includes							       
 *----------------------------------------------------------------------------*/
#include "cgu.h"

/*------------------------------------------------------------------------------
 * Methods
 *----------------------------------------------------------------------------*/
cgu::cgu( sc_module_name module_name) :
  sc_module(module_name), 
  pv_slave_base<ADDRESS_TYPE,DATA_TYPE>(name()),
  apb_slave_port ("apb_slave_port"),
  clkin ("clkin"),
  clkout ("clkout")
{
  apb_slave_port( *this );
  SC_METHOD( gen_clocks );
  sensitive << clkin.pos();
  init_registers();
}

tlm::tlm_status cgu::write( const ADDRESS_TYPE &addr , const DATA_TYPE &data,
			    const unsigned int byte_enable,
			    const tlm::tlm_mode mode,
			    const unsigned int export_id )
{
  tlm::tlm_status status;
  if ((addr / 4) < NUMCLOCKS) {
    registers[addr/4] = data;
  }
  status.set_ok();
  return status;
}

tlm::tlm_status cgu::read ( const ADDRESS_TYPE &addr , DATA_TYPE &data,
			    const unsigned int byte_enable,
			    const tlm::tlm_mode mode,
			    const unsigned int export_id)
{
  tlm::tlm_status status;
  if ((addr/4) < NUMCLOCKS) { // read the registers
    data = registers[addr/4];
  } else if ( addr == 0xFFC) { // read the ID register
    data = 0xD00;
  } else {
    data = 0x0;
  }
  status.set_ok();
  return status;
}

void cgu::gen_clocks()
{
  for (int i=0; i<NUMCLOCKS; i++) {
    if (registers[i] == 0) clkout.write(0);
    else                   clkout.write(1);
  }
}

void cgu::init_registers()
{
 for (int i=0;i<NUMCLOCKS;i++) registers[i]=0;
}

